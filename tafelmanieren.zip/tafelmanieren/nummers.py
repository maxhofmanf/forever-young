for x in range(20, 51):
    print(x)