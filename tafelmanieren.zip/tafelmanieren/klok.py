for i in range (1, 12):
    print (i , ("AM"))
for i in range (1, 12):
    print (i , ("pm"))