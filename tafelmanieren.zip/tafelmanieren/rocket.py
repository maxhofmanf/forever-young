for number in range(30):
    print(30 - number)
print("rocket has launched")